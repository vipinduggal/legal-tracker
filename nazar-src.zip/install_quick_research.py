import os, json

home = os.path.expanduser("~")
base = os.path.join(home, "legal-tracker")

# ── 1. Backend route: src/routes/quickResearch.js ─────────────────────────
route_path = os.path.join(base, "src", "routes", "quickResearch.js")
os.makedirs(os.path.dirname(route_path), exist_ok=True)

route = '''// quickResearch.js
// On-demand research for any company — no account list required
// POST /api/quick-research { company: "Company Name", email: true/false }

import express from "express";
import Anthropic from "@anthropic-ai/sdk";
import { sendEmail } from "../emailer.js";
import { logger } from "../logger.js";

const router = express.Router();
const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// Use Perplexity for live research
async function perplexitySearch(query) {
  const response = await fetch("https://api.perplexity.ai/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${process.env.PERPLEXITY_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "llama-3.1-sonar-large-128k-online",
      messages: [{ role: "user", content: query }],
      max_tokens: 2000,
    }),
  });
  const data = await response.json();
  return data.choices?.[0]?.message?.content || "";
}

router.post("/", async (req, res) => {
  const { company, sendEmailReport } = req.body;
  if (!company || company.trim().length < 2) {
    return res.status(400).json({ error: "Company name required" });
  }

  const companyName = company.trim();
  logger.info(`Quick research requested for: ${companyName}`);

  // Stream progress back via SSE — not needed here, just return JSON
  try {
    // Run 4 parallel Perplexity searches
    const [litigationRaw, financialRaw, contactsRaw, newsRaw] = await Promise.all([
      perplexitySearch(`Current litigation, lawsuits, regulatory actions involving ${companyName} legal department 2024 2025 2026. Include case names, courts, outside counsel if known.`),
      perplexitySearch(`${companyName} financial news, revenue, budget, M&A activity, layoffs, restructuring 2025 2026`),
      perplexitySearch(`${companyName} General Counsel, Chief Legal Officer, Head of Litigation, Head of Legal Operations, Deputy GC name title 2025 2026`),
      perplexitySearch(`${companyName} latest news, announcements, strategic developments May 2026`),
    ]);

    // Claude synthesizes into structured output
    const prompt = `You are a legal sales intelligence analyst. Synthesize this research on ${companyName} into a structured briefing for a Consilio eDiscovery sales rep.

LITIGATION DATA:
${litigationRaw}

FINANCIAL DATA:
${financialRaw}

CONTACTS DATA:
${contactsRaw}

RECENT NEWS:
${newsRaw}

Return a JSON object with this exact structure:
{
  "company": "${companyName}",
  "research_date": "${new Date().toISOString().split('T')[0]}",
  "executive_summary": "2-3 sentence overview of eDiscovery opportunity",
  "contacts": [
    {"name": "string", "title": "string", "confidence": "High|Medium|Low"}
  ],
  "litigation": [
    {"type": "string", "summary": "string", "status": "string", "outside_counsel": "string or null"}
  ],
  "financial_signals": ["string array of relevant financial signals"],
  "immediate_triggers": [
    {"trigger": "string", "urgency": "High|Medium|Low", "action": "string"}
  ],
  "strategic_notes": "string — longer term opportunity notes",
  "ediscovery_opportunity": "High|Medium|Low|Unknown"
}

Return JSON only. No markdown fences.`;

    const response = await client.messages.create({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 2000,
      messages: [{ role: "user", content: prompt }],
    });

    const raw = response.content.filter(b => b.type === "text").map(b => b.text).join("").trim();
    let result;
    try {
      result = JSON.parse(raw);
    } catch(e) {
      // Try to extract JSON
      const start = raw.indexOf("{");
      const end = raw.lastIndexOf("}");
      if (start > -1 && end > start) {
        result = JSON.parse(raw.slice(start, end + 1));
      } else {
        throw new Error("Could not parse Claude response as JSON");
      }
    }

    // Send email if requested
    if (sendEmailReport && process.env.EMAIL_TO) {
      const emailHtml = buildQuickResearchEmail(result);
      await sendEmail(
        process.env.EMAIL_TO,
        `[Nazar] Quick Research: ${companyName}`,
        emailHtml
      );
      logger.info(`Quick research email sent for ${companyName}`);
    }

    logger.info(`Quick research complete for ${companyName}`);
    return res.json({ success: true, data: result });

  } catch(err) {
    logger.error(`Quick research failed for ${companyName}`, { error: err.message });
    return res.status(500).json({ error: err.message });
  }
});

function buildQuickResearchEmail(data) {
  const urgencyColor = data.ediscovery_opportunity === "High" ? "#DC2626" :
                       data.ediscovery_opportunity === "Medium" ? "#D97706" : "#059669";

  const contactsHtml = (data.contacts || []).map(c =>
    `<tr><td style="padding:8px 12px;border-bottom:1px solid #f0f0f0">${c.name}</td>
     <td style="padding:8px 12px;border-bottom:1px solid #f0f0f0;color:#555">${c.title}</td>
     <td style="padding:8px 12px;border-bottom:1px solid #f0f0f0;color:#888;font-size:12px">${c.confidence}</td></tr>`
  ).join("");

  const litHtml = (data.litigation || []).map(l =>
    `<div style="border-left:3px solid #DC2626;padding:10px 14px;margin-bottom:10px;background:#FEF2F2;border-radius:0 6px 6px 0">
      <div style="font-weight:600;font-size:14px">${l.type}</div>
      <div style="color:#555;font-size:13px;margin-top:4px">${l.summary}</div>
      ${l.outside_counsel ? `<div style="color:#888;font-size:12px;margin-top:4px">Counsel: ${l.outside_counsel}</div>` : ""}
    </div>`
  ).join("");

  const triggersHtml = (data.immediate_triggers || []).map(t =>
    `<div style="border:1px solid #e0e0e0;border-radius:6px;padding:12px 14px;margin-bottom:10px">
      <div style="font-weight:600;font-size:13px;color:#1B3A5C">${t.trigger}</div>
      <div style="color:#0E7C6E;font-size:12px;margin-top:4px">→ ${t.action}</div>
    </div>`
  ).join("");

  return `<div style="font-family:Arial,sans-serif;max-width:640px;margin:0 auto">
    <div style="background:#1B3A5C;padding:24px;border-radius:8px 8px 0 0">
      <div style="font-size:11px;color:#aaa;letter-spacing:0.1em;text-transform:uppercase;margin-bottom:4px">Quick Research Report</div>
      <h1 style="color:white;margin:0;font-size:24px">${data.company}</h1>
      <div style="margin-top:8px">
        <span style="background:${urgencyColor};color:white;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px">
          ${data.ediscovery_opportunity} eDiscovery Opportunity
        </span>
      </div>
    </div>
    <div style="background:#f8f9fa;padding:24px;border-radius:0 0 8px 8px">
      <p style="color:#333;font-size:15px;line-height:1.7;margin-bottom:24px">${data.executive_summary}</p>
      
      ${data.contacts?.length ? `
      <h3 style="color:#1B3A5C;font-size:14px;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:12px">Key Contacts</h3>
      <table style="width:100%;border-collapse:collapse;margin-bottom:24px;background:white;border-radius:6px;overflow:hidden">
        ${contactsHtml}
      </table>` : ""}

      ${data.litigation?.length ? `
      <h3 style="color:#1B3A5C;font-size:14px;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:12px">Active Litigation</h3>
      <div style="margin-bottom:24px">${litHtml}</div>` : ""}

      ${data.immediate_triggers?.length ? `
      <h3 style="color:#1B3A5C;font-size:14px;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:12px">Immediate Triggers</h3>
      <div style="margin-bottom:24px">${triggersHtml}</div>` : ""}

      ${data.strategic_notes ? `
      <h3 style="color:#1B3A5C;font-size:14px;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:8px">Strategic Notes</h3>
      <p style="color:#555;font-size:13px;line-height:1.7">${data.strategic_notes}</p>` : ""}

      <div style="margin-top:24px;text-align:center">
        <a href="https://nazar-ai.com/research" style="background:#1B3A5C;color:white;padding:10px 24px;border-radius:6px;text-decoration:none;font-size:14px">Open Nazar Dashboard</a>
      </div>
      <div style="margin-top:16px;text-align:center;font-size:11px;color:#aaa">
        Generated ${new Date().toLocaleDateString("en-US", {weekday:"long",year:"numeric",month:"long",day:"numeric"})} · nazar-ai.com
      </div>
    </div>
  </div>`;
}

export default router;
''';

with open(route_path, "w") as f:
    f.write(route)
print("Done — quickResearch.js route written")

# ── 2. Register route in server.js ─────────────────────────────────────────
server_path = os.path.join(base, "src", "server.js")
with open(server_path, "r") as f:
    server = f.read()

if "quickResearch" not in server:
    old_import = "import { accountRoutes } from './accountRoutes.js';"
    if old_import in server:
        server = server.replace(old_import,
            old_import + "\nimport quickResearchRouter from './routes/quickResearch.js';")
        print("Done — quickResearch imported in server.js")

    # Register the route
    old_use = "app.use('/api/accounts', accountRoutes);"
    if old_use in server:
        server = server.replace(old_use,
            old_use + "\napp.use('/api/quick-research', quickResearchRouter);")
        print("Done — /api/quick-research route registered")

    # Serve the research page
    old_health = "app.get('/health',"
    if old_health in server:
        server = server.replace(old_health,
            "app.get('/research', (req, res) => res.sendFile(path.join(__dirname, 'research.html')));\n\n" + old_health)
        print("Done — /research page route added")

    with open(server_path, "w") as f:
        f.write(server)

# ── 3. Build research.html ──────────────────────────────────────────────────
research_html_path = os.path.join(base, "src", "research.html")

html = r'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Quick Research — Nazar</title>
<style>
  :root {
    --ink: #0E1117; --slate: #1C2333; --gold: #C9A84C; --gold-pale: #FBF3E0;
    --cream: #FDFAF4; --white: #fff; --g0: #F8F9FA; --g4: #6B7280;
    --g6: #374151; --g9: #111827; --red: #DC2626; --rl: #FEF2F2;
    --green: #059669; --amber: #D97706; --r: 8px;
    --shadow: 0 2px 12px rgba(0,0,0,0.08);
  }
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    background: var(--cream); color: var(--g9); min-height: 100vh; }

  /* NAV */
  nav {
    background: var(--slate); padding: 0 32px; height: 52px;
    display: flex; align-items: center; justify-content: space-between;
    position: sticky; top: 0; z-index: 100;
  }
  .nav-logo { font-size: 16px; font-weight: 700; color: var(--gold); letter-spacing: 0.06em; }
  .nav-links { display: flex; gap: 24px; }
  .nav-links a {
    font-size: 12px; font-weight: 600; letter-spacing: 0.08em;
    text-transform: uppercase; color: rgba(255,255,255,0.5);
    text-decoration: none; transition: color 0.2s;
  }
  .nav-links a:hover, .nav-links a.active { color: var(--gold); }

  /* MAIN */
  main { max-width: 860px; margin: 0 auto; padding: 40px 24px 80px; }

  /* SEARCH BOX */
  .search-section {
    background: var(--white); border: 1px solid rgba(0,0,0,0.08);
    border-radius: 16px; padding: 32px; margin-bottom: 32px;
    box-shadow: var(--shadow);
  }
  .search-title {
    font-size: 22px; font-weight: 700; color: var(--slate);
    margin-bottom: 6px;
  }
  .search-sub { font-size: 14px; color: var(--g4); margin-bottom: 24px; }
  .search-row { display: flex; gap: 12px; margin-bottom: 16px; }
  .search-input {
    flex: 1; height: 48px; padding: 0 16px;
    border: 1.5px solid rgba(0,0,0,0.12); border-radius: 10px;
    font-size: 15px; font-family: inherit; color: var(--g9);
    outline: none; transition: border-color 0.2s;
  }
  .search-input:focus { border-color: var(--gold); }
  .search-btn {
    height: 48px; padding: 0 24px;
    background: var(--slate); color: white;
    border: none; border-radius: 10px;
    font-size: 14px; font-weight: 600; cursor: pointer;
    transition: background 0.2s; white-space: nowrap;
  }
  .search-btn:hover { background: #2E3A50; }
  .search-btn:disabled { opacity: 0.5; cursor: not-allowed; }
  .email-toggle {
    display: flex; align-items: center; gap: 8px;
    font-size: 13px; color: var(--g4); cursor: pointer;
  }
  .email-toggle input { accent-color: var(--gold); width: 16px; height: 16px; cursor: pointer; }

  /* PROGRESS */
  .progress-wrap { display: none; margin-top: 20px; }
  .progress-wrap.show { display: block; }
  .progress-bar-track {
    height: 4px; background: rgba(0,0,0,0.08); border-radius: 2px; overflow: hidden;
  }
  .progress-bar-fill {
    height: 100%; background: var(--gold); border-radius: 2px;
    width: 0%; transition: width 0.5s ease;
  }
  .progress-steps { display: flex; gap: 8px; margin-top: 12px; flex-wrap: wrap; }
  .progress-step {
    font-size: 11px; padding: 3px 10px; border-radius: 20px;
    background: var(--g0); color: var(--g4); font-weight: 600;
    border: 1px solid rgba(0,0,0,0.08); transition: all 0.3s;
  }
  .progress-step.active { background: var(--gold-pale); color: var(--gold); border-color: rgba(201,168,76,0.4); }
  .progress-step.done { background: #F0FDF4; color: var(--green); border-color: rgba(5,150,105,0.3); }

  /* RESULTS */
  #results { display: none; }
  #results.show { display: block; }

  /* OPPORTUNITY BADGE */
  .opp-badge {
    display: inline-flex; align-items: center; gap: 6px;
    font-size: 12px; font-weight: 700; padding: 4px 12px; border-radius: 20px;
  }
  .opp-High { background: var(--rl); color: var(--red); }
  .opp-Medium { background: #FEF3C7; color: var(--amber); }
  .opp-Low { background: #F0FDF4; color: var(--green); }
  .opp-Unknown { background: var(--g0); color: var(--g4); }

  /* RESULT HEADER */
  .result-header {
    background: var(--slate); border-radius: 16px 16px 0 0;
    padding: 24px 28px; display: flex; justify-content: space-between; align-items: flex-start;
  }
  .result-company { font-size: 24px; font-weight: 700; color: white; margin-bottom: 6px; }
  .result-date { font-size: 12px; color: rgba(255,255,255,0.4); }
  .result-summary {
    background: white; border: 1px solid rgba(0,0,0,0.08);
    border-top: none; padding: 20px 28px;
    font-size: 15px; color: var(--g6); line-height: 1.7;
  }

  /* SECTIONS */
  .result-section {
    background: white; border: 1px solid rgba(0,0,0,0.08);
    border-top: none; padding: 20px 28px;
  }
  .result-section:last-child { border-radius: 0 0 16px 16px; margin-bottom: 32px; }
  .section-label {
    font-size: 11px; font-weight: 700; letter-spacing: 0.12em;
    text-transform: uppercase; color: var(--g4); margin-bottom: 14px;
    display: flex; align-items: center; gap: 8px;
  }
  .section-label::after {
    content: ''; flex: 1; height: 1px; background: rgba(0,0,0,0.08); max-width: 80px;
  }

  /* CONTACTS TABLE */
  .contacts-table { width: 100%; border-collapse: collapse; }
  .contacts-table td { padding: 9px 12px; font-size: 13px; border-bottom: 1px solid var(--g0); }
  .contacts-table tr:last-child td { border-bottom: none; }
  .contacts-table .name { font-weight: 600; color: var(--g9); }
  .contacts-table .title { color: var(--g4); }
  .conf-High { color: var(--green); font-size: 11px; font-weight: 700; }
  .conf-Medium { color: var(--amber); font-size: 11px; font-weight: 700; }
  .conf-Low { color: var(--g4); font-size: 11px; }

  /* LITIGATION */
  .lit-item {
    border-left: 3px solid var(--red); border-radius: 0 8px 8px 0;
    background: var(--rl); padding: 12px 14px; margin-bottom: 10px;
  }
  .lit-type { font-size: 13px; font-weight: 700; color: var(--g9); margin-bottom: 4px; }
  .lit-summary { font-size: 13px; color: var(--g4); line-height: 1.6; }
  .lit-counsel { font-size: 12px; color: var(--g4); margin-top: 4px; }

  /* TRIGGERS */
  .trigger-item {
    border: 1px solid rgba(0,0,0,0.08); border-radius: 8px;
    padding: 12px 14px; margin-bottom: 10px; background: var(--g0);
  }
  .trigger-text { font-size: 13px; font-weight: 600; color: var(--g9); margin-bottom: 4px; }
  .trigger-action { font-size: 12px; color: var(--green); }
  .trigger-urgency-High { border-left: 3px solid var(--red); }
  .trigger-urgency-Medium { border-left: 3px solid var(--amber); }
  .trigger-urgency-Low { border-left: 3px solid var(--green); }

  /* SIGNALS */
  .signals-list { list-style: none; }
  .signals-list li {
    font-size: 13px; color: var(--g6); padding: 7px 0;
    border-bottom: 1px solid var(--g0); display: flex; gap: 8px; align-items: flex-start;
  }
  .signals-list li::before { content: '→'; color: var(--gold); flex-shrink: 0; }
  .signals-list li:last-child { border-bottom: none; }

  /* ACTIONS */
  .result-actions {
    display: flex; gap: 12px; margin-top: 4px;
  }
  .action-btn {
    height: 36px; padding: 0 16px; border-radius: 8px;
    font-size: 13px; font-weight: 600; cursor: pointer;
    border: 1.5px solid rgba(0,0,0,0.12); background: white;
    color: var(--g6); transition: all 0.2s;
  }
  .action-btn:hover { border-color: var(--gold); color: var(--gold); }
  .action-btn.primary { background: var(--slate); color: white; border-color: transparent; }
  .action-btn.primary:hover { background: #2E3A50; }

  /* ERROR */
  .error-box {
    background: var(--rl); border: 1px solid rgba(220,38,38,0.2);
    border-radius: 10px; padding: 16px 20px;
    font-size: 14px; color: var(--red); margin-top: 16px;
    display: none;
  }
  .error-box.show { display: block; }

  /* HISTORY */
  .history-section {
    background: var(--white); border: 1px solid rgba(0,0,0,0.08);
    border-radius: 16px; padding: 24px 28px;
    box-shadow: var(--shadow);
  }
  .history-title { font-size: 15px; font-weight: 700; color: var(--slate); margin-bottom: 16px; }
  .history-empty { font-size: 13px; color: var(--g4); }
  .history-item {
    display: flex; justify-content: space-between; align-items: center;
    padding: 10px 0; border-bottom: 1px solid var(--g0); cursor: pointer;
  }
  .history-item:last-child { border-bottom: none; }
  .history-item:hover .history-name { color: var(--gold); }
  .history-name { font-size: 14px; font-weight: 600; color: var(--g9); }
  .history-meta { font-size: 12px; color: var(--g4); }
</style>
</head>
<body>

<nav>
  <div class="nav-logo">Nazar</div>
  <div class="nav-links">
    <a href="/">Dashboard</a>
    <a href="/research" class="active">Quick Research</a>
    <a href="/digest">Digest</a>
  </div>
</nav>

<main>
  <!-- SEARCH -->
  <div class="search-section">
    <div class="search-title">Quick Company Research</div>
    <div class="search-sub">Get a full intelligence brief on any company in ~30 seconds. No account list required.</div>
    <div class="search-row">
      <input type="text" class="search-input" id="companyInput"
        placeholder="Enter company name — e.g. Microsoft, Coupang, Anthropic..."
        onkeydown="if(event.key==='Enter')runResearch()">
      <button class="search-btn" id="searchBtn" onclick="runResearch()">Research</button>
    </div>
    <label class="email-toggle">
      <input type="checkbox" id="emailToggle" checked>
      Email me this report when done
    </label>
    <div class="progress-wrap" id="progressWrap">
      <div class="progress-bar-track">
        <div class="progress-bar-fill" id="progressFill"></div>
      </div>
      <div class="progress-steps">
        <div class="progress-step" id="step1">Searching litigation</div>
        <div class="progress-step" id="step2">Searching financials</div>
        <div class="progress-step" id="step3">Finding contacts</div>
        <div class="progress-step" id="step4">Scanning news</div>
        <div class="progress-step" id="step5">Synthesizing</div>
      </div>
    </div>
    <div class="error-box" id="errorBox"></div>
  </div>

  <!-- RESULTS -->
  <div id="results">
    <div class="result-header" id="resultHeader"></div>
    <div class="result-summary" id="resultSummary"></div>
    <div class="result-section" id="resultContacts"></div>
    <div class="result-section" id="resultLitigation"></div>
    <div class="result-section" id="resultTriggers"></div>
    <div class="result-section" id="resultSignals"></div>
    <div class="result-section" id="resultNotes" style="border-radius:0 0 16px 16px"></div>
  </div>

  <!-- HISTORY -->
  <div class="history-section" id="historySection">
    <div class="history-title">Recent Searches</div>
    <div id="historyList"><div class="history-empty">No recent searches yet.</div></div>
  </div>
</main>

<script>
let history = JSON.parse(sessionStorage.getItem('qr_history') || '[]');
renderHistory();

async function runResearch() {
  const company = document.getElementById('companyInput').value.trim();
  if (!company) { document.getElementById('companyInput').focus(); return; }

  const btn = document.getElementById('searchBtn');
  btn.disabled = true; btn.textContent = 'Researching...';

  // Show progress
  const pw = document.getElementById('progressWrap');
  pw.classList.add('show');
  document.getElementById('errorBox').classList.remove('show');
  document.getElementById('results').classList.remove('show');

  // Animate progress
  const steps = ['step1','step2','step3','step4','step5'];
  const fill = document.getElementById('progressFill');
  let currentStep = 0;

  const progressInterval = setInterval(() => {
    if (currentStep > 0) document.getElementById(steps[currentStep-1]).classList.remove('active');
    if (currentStep < steps.length) {
      document.getElementById(steps[currentStep]).classList.add('active');
      fill.style.width = ((currentStep+1)/steps.length * 85) + '%';
      currentStep++;
    }
  }, 5000);

  try {
    const resp = await fetch('/api/quick-research', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        company,
        sendEmailReport: document.getElementById('emailToggle').checked
      })
    });

    clearInterval(progressInterval);

    if (!resp.ok) {
      const err = await resp.json();
      throw new Error(err.error || 'Research failed');
    }

    const { data } = await resp.json();

    // Complete progress
    steps.forEach(s => {
      document.getElementById(s).classList.remove('active');
      document.getElementById(s).classList.add('done');
    });
    fill.style.width = '100%';

    // Save to history
    history.unshift({ company: data.company, date: data.research_date, opportunity: data.ediscovery_opportunity, data });
    if (history.length > 10) history.pop();
    sessionStorage.setItem('qr_history', JSON.stringify(history));
    renderHistory();

    // Render results
    renderResults(data);

    setTimeout(() => { pw.classList.remove('show'); }, 1000);

  } catch(err) {
    clearInterval(progressInterval);
    pw.classList.remove('show');
    const eb = document.getElementById('errorBox');
    eb.textContent = 'Research failed: ' + err.message;
    eb.classList.add('show');
  } finally {
    btn.disabled = false; btn.textContent = 'Research';
  }
}

function oppClass(opp) { return 'opp-' + (opp || 'Unknown'); }

function renderResults(d) {
  const res = document.getElementById('results');

  // Header
  document.getElementById('resultHeader').innerHTML = `
    <div>
      <div class="result-company">${d.company}</div>
      <div class="result-date">Researched ${d.research_date}</div>
    </div>
    <div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px">
      <span class="opp-badge ${oppClass(d.ediscovery_opportunity)}">${d.ediscovery_opportunity || 'Unknown'} Opportunity</span>
      <div class="result-actions">
        <button class="action-btn" onclick="window.print()">Print</button>
        <button class="action-btn primary" onclick="addToAccounts('${d.company}')">Add to Accounts</button>
      </div>
    </div>`;

  // Summary
  document.getElementById('resultSummary').innerHTML = d.executive_summary || '';

  // Contacts
  const contacts = d.contacts || [];
  document.getElementById('resultContacts').innerHTML = contacts.length ? `
    <div class="section-label">Key Contacts</div>
    <table class="contacts-table">
      ${contacts.map(c => `<tr>
        <td class="name">${c.name}</td>
        <td class="title">${c.title}</td>
        <td class="conf-${c.confidence}">${c.confidence}</td>
      </tr>`).join('')}
    </table>` : '<div class="section-label">Key Contacts</div><div style="font-size:13px;color:#9CA3AF">No contacts identified</div>';

  // Litigation
  const lit = d.litigation || [];
  document.getElementById('resultLitigation').innerHTML = lit.length ? `
    <div class="section-label">Active Litigation</div>
    ${lit.map(l => `<div class="lit-item">
      <div class="lit-type">${l.type} <span style="font-size:11px;font-weight:400;color:#9CA3AF">${l.status}</span></div>
      <div class="lit-summary">${l.summary}</div>
      ${l.outside_counsel ? `<div class="lit-counsel">Outside counsel: ${l.outside_counsel}</div>` : ''}
    </div>`).join('')}` : '<div class="section-label">Active Litigation</div><div style="font-size:13px;color:#9CA3AF">No significant litigation identified</div>';

  // Triggers
  const triggers = d.immediate_triggers || [];
  document.getElementById('resultTriggers').innerHTML = triggers.length ? `
    <div class="section-label">Immediate Triggers</div>
    ${triggers.map(t => `<div class="trigger-item trigger-urgency-${t.urgency}">
      <div class="trigger-text">${t.trigger}</div>
      <div class="trigger-action">→ ${t.action}</div>
    </div>`).join('')}` : '<div class="section-label">Immediate Triggers</div><div style="font-size:13px;color:#9CA3AF">No immediate triggers identified</div>';

  // Signals
  const signals = d.financial_signals || [];
  document.getElementById('resultSignals').innerHTML = signals.length ? `
    <div class="section-label">Financial Signals</div>
    <ul class="signals-list">
      ${signals.map(s => `<li>${s}</li>`).join('')}
    </ul>` : '<div class="section-label">Financial Signals</div><div style="font-size:13px;color:#9CA3AF">No significant financial signals</div>';

  // Notes
  document.getElementById('resultNotes').innerHTML = d.strategic_notes ? `
    <div class="section-label">Strategic Notes</div>
    <div style="font-size:14px;color:#374151;line-height:1.7">${d.strategic_notes}</div>` : '';

  res.classList.add('show');
  res.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function addToAccounts(company) {
  if (confirm('Add ' + company + ' to your monitored accounts list?')) {
    window.location.href = '/?addAccount=' + encodeURIComponent(company);
  }
}

function renderHistory() {
  const el = document.getElementById('historyList');
  if (!history.length) {
    el.innerHTML = '<div class="history-empty">No recent searches yet.</div>';
    return;
  }
  el.innerHTML = history.map((h, i) => `
    <div class="history-item" onclick="renderResults(${JSON.stringify(h.data).replace(/"/g, '&quot;')})">
      <div>
        <div class="history-name">${h.company}</div>
        <div class="history-meta">${h.date}</div>
      </div>
      <span class="opp-badge ${oppClass(h.opportunity)}" style="font-size:11px">${h.opportunity || 'Unknown'}</span>
    </div>`).join('');
}
</script>
</body>
</html>''';

with open(research_html_path, "w") as f:
    f.write(html)
print("Done — research.html written")

# ── 4. Add link to dashboard nav ───────────────────────────────────────────
dashboard_path = os.path.join(base, "src", "dashboard.html")
with open(dashboard_path, "r") as f:
    dash = f.read()

# Add Quick Research link to nav if not present
if "/research" not in dash:
    old_nav = 'href="/digest"'
    new_nav = 'href="/digest"\n      <a href="/research" style="color:rgba(255,255,255,0.6);text-decoration:none;font-size:12px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;padding:6px 14px;border:1px solid rgba(201,168,76,0.4);border-radius:6px;color:var(--gold)">Quick Research</a'
    if old_nav in dash:
        dash = dash.replace(old_nav, new_nav)
        with open(dashboard_path, "w") as f:
            f.write(dash)
        print("Done — Quick Research link added to dashboard nav")
    else:
        print("WARNING — dashboard nav pattern not found — add link manually")

print("")
print("="*55)
print("QUICK RESEARCH INSTALLED")
print("="*55)
print("")
print("What was built:")
print("  - /research page — search any company, get instant brief")
print("  - Results show: contacts, litigation, triggers, signals")
print("  - Email toggle — sends full formatted report via SendGrid")
print("  - Session history — last 10 searches saved")
print("  - Add to Accounts button — one click to monitor")
print("  - Uses Claude Haiku (cheap) + Perplexity (live data)")
print("")
print("Deploy:")
print("  git add . && git commit -m 'Quick Research page' && git push")
print("  ssh root@143.110.146.121")
print("  cd ~/legal-tracker && git pull && pm2 restart legal-tracker")
print("")
print("Then visit: https://nazar-ai.com/research")
